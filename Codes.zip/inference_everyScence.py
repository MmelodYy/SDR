import tensorflow.compat.v1 as tf

tf.disable_v2_behavior()
import os
import time
import numpy as np
import pickle
import cv2

from PIL import Image
from model import RectanglingNetwork
from utils import load, save, DataLoader
import matplotlib.pyplot as plt
import skimage
import imageio

import constant

os.environ['CUDA_DEVICES_ORDER'] = "PCI_BUS_ID"
os.environ['CUDA_VISIBLE_DEVICES'] = constant.GPU

test_folder = constant.TEST_FOLDER
batch_size = constant.TEST_BATCH_SIZE

# snapshot_dir = constant.SNAPSHOT_DIR + '/pretrained_model/model.ckpt-100000'
snapshot_dir = './checkpoints/model.ckpt-100000'

batch_size = 1

# define dataset
with tf.name_scope('dataset'):
    ##########testing###############
    test_inputs_clips_tensor = tf.placeholder(shape=[batch_size, None, None, 3 * 3], dtype=tf.float32)

    test_input = test_inputs_clips_tensor[..., 0:3]
    test_mask = test_inputs_clips_tensor[..., 3:6]
    test_gt = test_inputs_clips_tensor[..., 6:9]

    print('test input = {}'.format(test_input))
    print('test mask = {}'.format(test_mask))
    print('test gt = {}'.format(test_gt))

# define testing generator function
with tf.variable_scope('generator', reuse=None):
    print('testing = {}'.format(tf.get_variable_scope().name))
    test_mesh_primary, test_warp_image_primary, test_warp_mask_primary, test_mesh_mid, test_warp_image_mid, test_warp_mask_mid, \
    test_mesh_final, test_warp_image_final, test_warp_mask_final = RectanglingNetwork(test_input, test_mask)

config = tf.ConfigProto()
config.gpu_options.allow_growth = True
with tf.Session(config=config) as sess:
    # initialize weights
    sess.run(tf.global_variables_initializer())
    print('Init global successfully!')

    # tf saver
    saver = tf.train.Saver(var_list=tf.global_variables(), max_to_keep=None)

    restore_var = [v for v in tf.global_variables()]
    loader = tf.train.Saver(var_list=restore_var)
    print("============")
    print(snapshot_dir)
    load(loader, sess, snapshot_dir)
    print("============")

    scenceList = ['close shot', 'high-light', 'Linear', 'long shot', 'low-light', 'low-texture',
                  'moving foreground', 'Nonlinear']
    all_psnr_list = []
    all_ssim_list = []
    all_psnr_list_sum = []
    all_ssim_list_sum = []
    pathFull = 'D:/wmsspace/MyData/DIR-D/testing'
    # dataset
    input_loader = DataLoader(pathFull)
    for scence in scenceList:
        imgIdxAll = list(sorted(os.listdir(os.path.join(test_folder,scence,'input'))))
        imgIdxToNum = [int(img.split(".jpg")[0]) for img in imgIdxAll]
        print("=====",scence)
        print("imgIdxToNum:",imgIdxToNum)
        psnr_list = []
        ssim_list = []
        length = len(imgIdxToNum)
        for i,img_idx in enumerate(imgIdxToNum):

            input_clip = np.expand_dims(input_loader.get_data_clips(img_idx-1), axis=0)

            mesh_primary, warp_image_primary, warp_mask_primary, mesh_mid, warp_image_mid, warp_mask_mid, \
            mesh_final, warp_image_final, warp_mask_final = sess.run(
                [test_mesh_primary, test_warp_image_primary, test_warp_mask_primary, test_mesh_mid, test_warp_image_mid,
                 test_warp_mask_mid,
                 test_mesh_final, test_warp_image_final, test_warp_mask_final],
                feed_dict={test_inputs_clips_tensor: input_clip})

            warp_image3 = (warp_image_final[0] + 1) * 127.5
            warp_gt = (input_clip[0, :, :, 6:9] + 1) * 127.5

            psnr = skimage.metrics.peak_signal_noise_ratio(warp_image3, warp_gt, data_range=255)
            ssim = skimage.metrics.structural_similarity(warp_image3, warp_gt, data_range=255, multichannel=True)

            print('i = {} / {}, imgIdX:{}, psnr = {:.6f}'.format(i + 1, length, img_idx, psnr))

            psnr_list.append(psnr)
            ssim_list.append(ssim)
            all_psnr_list_sum.append(psnr)
            all_ssim_list_sum.append(ssim)

        all_psnr_list.append(np.mean(psnr_list))
        all_ssim_list.append(np.mean(ssim_list))

    print("===================Results Analysis==================")
    print('psnr: close shot:', all_psnr_list[0],'high-light:', all_psnr_list[1],'Linear:',all_psnr_list[2], 'long shot:',all_psnr_list[3],
          'low-light:', all_psnr_list[4],'low-texture:',all_psnr_list[5],
              'moving foreground:',all_psnr_list[6], 'Nonlinear:',all_psnr_list[7],'average psnr:',np.mean(all_psnr_list_sum))

    print('ssim: close shot:', all_ssim_list[0], 'high-light', all_ssim_list[1], 'Linear:', all_ssim_list[2], 'long shot:',
          all_ssim_list[3],'low-light:', all_ssim_list[4], 'low-texture:', all_ssim_list[5],
          'moving foreground:', all_ssim_list[6], 'Nonlinear:', all_ssim_list[7],'average ssim:', np.mean(all_ssim_list_sum))
    # as for FID, we use the CODE from https://github.com/bioinf-jku/TTUR to evaluate











