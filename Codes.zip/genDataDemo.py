import os
import shutil

if __name__ == "__main__":
    scenceList = ['close shot','high-light','Linear','long shot','low-light','low-texture','moving foreground','Nonlinear']
    pathOr = r'D:\wmsspace\MyData\DIR-D-test'
    allDataPath = r'D:\wmsspace\MyData\testing'
    for i in range(len(scenceList)):
        path1 = os.path.join(pathOr,scenceList[i])
        # 筛选数据在input里面，需要生成mask和gt
        existFileName = 'gt'
        fileList = ['input', 'mask']
        print("---------done ",scenceList[i])
        for j in range(len(fileList)):
            childPath = os.path.join(path1,fileList[j])
            print("---------done ", scenceList[i]," ,----------",fileList[j])
            if not os.path.exists(childPath):
                os.mkdir(os.path.join(path1,fileList[j]))
            inputPath = os.path.join(path1,existFileName)
            imgNameAll = list(sorted(os.listdir(inputPath)))
            for name in imgNameAll:
                newPath = os.path.join(childPath,name)
                # print(newPath)
                # print(os.path.join(allDataPath,fileList[j],name))
                shutil.copy(os.path.join(allDataPath,fileList[j],name),newPath)



