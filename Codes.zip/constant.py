#training dataset path
TRAIN_FOLDER = 'D:/wmsspace/MyData/DIR-D/training'

#testing dataset path
#TEST_FOLDER = 'D:/wmsspace/MyData/DIR-D/testing'
# TEST_FOLDER = 'D:/wmsspace/MyData/DIR-D-test/Linear'
TEST_FOLDER = 'D:/wmsspace/MyData/DIR-D/testing'

#GPU index
GPU = '1'
GPU_DEVICE = "cuda"

#batch size for training
TRAIN_BATCH_SIZE = 4

#batch size for testing
TEST_BATCH_SIZE = 1

#num of iters
ITERATIONS = 100000

# checkpoints path
SNAPSHOT_DIR = "./checkpoints"

#sumary path
SUMMARY_DIR = "./summary"

# define the mesh resolution
GRID_W = 8
GRID_H = 6

